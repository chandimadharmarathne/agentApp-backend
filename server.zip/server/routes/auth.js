const express = require('express');
const router = express.Router();
const cors = require('cors'); // Import CORS middleware
const db = require('../db'); // Assuming this imports your database connection
const jwt = require('jsonwebtoken');
const SECRET_KEY = 'dms';

// Use CORS middleware
router.use(cors());

router.post('/login', (req, res) => {
  // console.log(req.body);
  const { extensionNumber, password } = req.body;
  // console.log('Received extensionNumber:', extensionNumber);
  // console.log('Received password:', password);
  // Query to check if user exists with provided credentials
  const query = `
    SELECT * FROM asterisk_cdr_rports.users
    WHERE extension = ? AND password = ?;
  `;

  db.query(query, [parseInt(extensionNumber), password], (error, results) => {
    if (error) {
      console.error('Error executing login query:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
    console.log('Query Results:', results);
    if (results.length > 0) {
      // Successful login
      const username = results[0].username;
      const tenants_id = results[0].tenants_id;
      const password = results[0].password;
      const extension = results[0].extension;
      const loginDate = new Date();
      

      const token = jwt.sign({ extension, password, username, tenants_id }, SECRET_KEY, { expiresIn: '1h' });
      console.log( 'username ', extension );
      // Insert login record into agent_login_logout table
      const insertQuery = `
        INSERT INTO asterisk_cdr_rports.agent_login_logout (extension, loginDate)
        VALUES (?, ?)
      `;

      db.query(insertQuery, [extensionNumber, loginDate], (insertError) => {
        if (insertError) {
          console.error('Error inserting login record:', insertError);
          return res.status(500).json({ error: 'Internal Server Error' });
        }

        //console.log("Login record inserted for extension:", extensionNumber);
        // return res.json({ username: username, tenants_id: tenants_id, success: true });
        return res.json({
      username: username,
      // tenants_id: tenants_id,
      extension:extension,
      success: true,
      token 
    });
      });
    } else {
      // Invalid credentials
      return res.status(401).json({ error: 'Invalid credentials' });
    }
  });
});


router.post('/logout', (req, res) => {
  const { extensionNumber, logoutReason } = req.body;
  const logoutDate = new Date();

  // Find the latest login record that doesn't have a logout date
  const findQuery = `
      SELECT * FROM asterisk_cdr_rports.agent_login_logout
      WHERE extension = ? AND logoutDate IS NULL
      ORDER BY loginDate DESC
      LIMIT 1
  `;

  db.query(findQuery, [extensionNumber], (error, results) => {
    if (error) {
      console.error('Error finding login record:', error); // Log the error
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (results.length > 0) {
      const loginRecord = results[0];
      const updateQuery = `
              UPDATE asterisk_cdr_rports.agent_login_logout
              SET logoutDate = ?, logoutReasonID = ?
              WHERE id = ?
          `;

      db.query(updateQuery, [logoutDate, logoutReason, loginRecord.id], (updateError, updateResults) => {
        if (updateError) {
          console.error('Error updating logout record:', updateError); // Log the error
          res.status(500).json({ error: 'Internal Server Error' });
          return;
        }

        // console.log("Logout record updated for extension:", extensionNumber);

        res.json({ success: true });
      });
    } else {
      res.status(404).json({ error: 'No active login record found or already logged out' });
    }
  });
});




module.exports = router;

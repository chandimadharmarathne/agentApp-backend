const jwt = require('jsonwebtoken');

const SECRET_KEY = 'dms'; // The same key used to sign the token

function verifyToken(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ error: 'No token provided' });

    jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) return res.status(500).json({ error: 'Failed to authenticate token' });

        req.userId = decoded.id;
        req.username = decoded.username;
        req.tenants_id = decoded.tenants_id;
        req.password = decoded.password;
        req.extension = decoded.extension;
        next();
    });
}

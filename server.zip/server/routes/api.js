// server/routes/api.js
const express = require('express');
const router = express.Router();
const db = require('../db'); // Import the db.js file

//Missed Call count
router.get('/missedCallCount', (req, res) => {
    const extensionNumber = req.query.extension;
    const query = `
        SELECT ? AS dst, COUNT(DISTINCT cdr.uniqueid) AS missed_call_count
        FROM asterisk_cdr_rports.cdr cdr
        WHERE cdr.uniqueid NOT IN (
            SELECT sub_cdr.uniqueid
            FROM asterisk_cdr_rports.cdr sub_cdr
            WHERE sub_cdr.disposition = 'ANSWER'
            AND sub_cdr.calldate >= CURDATE()
            AND sub_cdr.calldate < CURDATE() + INTERVAL 1 DAY
        )
        AND cdr.disposition = 'NO ANSWER'
        AND cdr.calldate >= CURDATE()
        AND cdr.calldate < CURDATE() + INTERVAL 1 DAY
        AND cdr.dstchannel LIKE ?;
    `;

    db.query(query, [extensionNumber, `%${extensionNumber}%`], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        const missedCallCount = results[0].missed_call_count; // Corrected alias name
        //console.log('Missed Call Count:', missedCallCount); // Log count to console
        res.json({ missed_call_count: missedCallCount }); // Respond with JSON containing count
    });
});

//Inbound Call count
router.get('/inboundCallCount', (req, res) => {
    const extensionNumber = req.query.extension;

    // console.log("inboundCallCount" , extensionNumber);
    const query = `
        select COUNT(DISTINCT uniqueid) AS inbound_call_count 
        from asterisk_cdr_rports.cdr 
        where dstchannel like ? 
        AND calldate >= CURDATE() 
        AND calldate < CURDATE() + INTERVAL 1 DAY 
        AND disposition = 'ANSWERED';
    `;

    db.query(query, [`%${extensionNumber}%`], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        const inboundCallCount = results[0].inbound_call_count; // Corrected alias name
        // console.log('Inbound Call Count:', inboundCallCount); // Log count to console
        res.json({ inbound_call_count: inboundCallCount }); // Respond with JSON containing count
    });
});

//Outbound Call count
router.get('/outboundCallCount', (req, res) => {
    const extensionNumber = req.query.extension;
    const query = `
        SELECT COUNT(DISTINCT uniqueid) AS outbound_call_count
        FROM asterisk_cdr_rports.cdr
        WHERE dstchannel LIKE '%my_sip_trunk%'
        AND calldate >= CURDATE()
        AND calldate < CURDATE() + INTERVAL 1 DAY
        AND lastapp = 'Dial'
        AND clid like ? ;
    `;

    db.query(query, [`%${extensionNumber}%`], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        const outboundCallCount = results[0].outbound_call_count; // Corrected alias name
        // console.log('Outbound Call Count:', outboundCallCount); // Log count to console
        res.json({ outbound_call_count: outboundCallCount }); // Respond with JSON containing count
    });
});

//service level-gauge chart
router.get('/service-level', (req, res) => {
    const extensionNumber = req.query.extension;
    // console.log("service-level", extensionNumber);
    const query = `
    SELECT username, extension,
        ((calls_15_or_less*4)+(calls_between_15_and_30*3)+(calls_between_30_and_45*2)+(calls_between_45_and_60*1))*100 /
        ((calls_15_or_less+calls_between_15_and_30+calls_between_30_and_45+calls_between_45_and_60)*5) AS service_level,
        (calls_15_or_less+calls_between_15_and_30+calls_between_30_and_45+calls_between_45_and_60) AS call_count
    FROM (
        SELECT
            subquery.username, extension,
            SUM(CASE WHEN subquery.hold_time <= 15 THEN 1 ELSE 0 END) AS calls_15_or_less,
            SUM(CASE WHEN subquery.hold_time > 15 AND subquery.hold_time <= 30 THEN 1 ELSE 0 END) AS calls_between_15_and_30,
            SUM(CASE WHEN subquery.hold_time > 30 AND subquery.hold_time <= 45 THEN 1 ELSE 0 END) AS calls_between_30_and_45,
            SUM(CASE WHEN subquery.hold_time > 45 AND subquery.hold_time <= 60 THEN 1 ELSE 0 END) AS calls_between_45_and_60
        FROM (
            SELECT
                q.id,
                q.timestamp,
                q.unique_id,
                q.queue_name,
                q.queue_member_channel,
                q.event_type,
                SUBSTRING_INDEX(SUBSTRING_INDEX(q.event_parameters, '|', 1), '|', -1) AS hold_time,
                SUBSTRING_INDEX(SUBSTRING_INDEX(q.event_parameters, '|', 2), '|', -1) AS talk_time,
                u.username,
                u.extension
            FROM
                asterisk_cdr_rports.test_queue_log q
            JOIN asterisk_cdr_rports.users u ON SUBSTRING_INDEX(SUBSTRING_INDEX(q.queue_member_channel, ' ', -1), '-', 1) = u.extension
            WHERE (q.event_type = 'COMPLETEAGENT' OR q.event_type = 'COMPLETECALLER') AND u.extension=?
        ) AS subquery
        GROUP BY subquery.username
    ) AS hold_time_counts;`;

    db.query(query, extensionNumber, (err, results) => {
        if (err) throw err;
        res.json(results[0]); // Assuming only one result
        // console.log("Service Level Query Result",results[0]);
    });
});

//chart
// Function to format dates for SQL queries
function formatDate(date) {
    return date.toISOString().split('T')[0]; // Formats date as YYYY-MM-DD
}

// Function to get the start date of the past 7 days
function getStartDate() {
    const today = new Date();
    const startDate = new Date(today);
    startDate.setDate(today.getDate() - 6); // Subtract 6 days from today
    return startDate;
}

// Function to fetch daily call counts for the past 7 days
async function fetchDailyCallCounts(extensionNumber) {
    const startDate = getStartDate();
    const endDate = new Date(); // Today's date
    // const extensionNumber = req.query.extension;
    // console.log('Hellow', extensionNumber);

    try {
        const promises = [];
        for (let i = 0; i < 7; i++) {
            const currentDate = new Date(startDate);
            currentDate.setDate(startDate.getDate() + i); // Increment date by i days
            const formattedDate = formatDate(currentDate);

            const inboundQuery = `
                SELECT COUNT(DISTINCT uniqueid) AS inbound_call_count 
                FROM asterisk_cdr_rports.cdr 
                WHERE dstchannel LIKE ? 
                AND calldate >= '${formattedDate}' 
                AND calldate < DATE_ADD('${formattedDate}', INTERVAL 1 DAY)
                AND disposition = 'ANSWERED';
            `;

            const outboundQuery = `
                SELECT COUNT(DISTINCT uniqueid) AS outbound_call_count
                FROM asterisk_cdr_rports.cdr
                WHERE dstchannel LIKE '%my_sip_trunk%'
                AND calldate >= '${formattedDate}'
                AND calldate < DATE_ADD('${formattedDate}', INTERVAL 1 DAY)
                AND clid LIKE ?;
            `;

            const missedQuery = `
                SELECT COUNT(DISTINCT cdr.uniqueid) AS missed_call_count
                FROM asterisk_cdr_rports.cdr cdr
                WHERE cdr.uniqueid NOT IN (
                    SELECT sub_cdr.uniqueid
                    FROM asterisk_cdr_rports.cdr sub_cdr
                    WHERE sub_cdr.disposition = 'ANSWER'
                    AND sub_cdr.calldate >= '${formattedDate}'
                    AND sub_cdr.calldate < DATE_ADD('${formattedDate}', INTERVAL 1 DAY)
                )
                AND cdr.disposition = 'NO ANSWER'
                AND cdr.calldate >= '${formattedDate}'
                AND cdr.calldate < DATE_ADD('${formattedDate}', INTERVAL 1 DAY)
                AND cdr.dstchannel LIKE ?;
            `;

            promises.push(
                new Promise((resolve, reject) => {
                    db.query(inboundQuery, [`%${extensionNumber}%`], (error, results) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve({ date: formattedDate, type: 'inbound', count: results[0].inbound_call_count });
                        }
                    });
                }),
                new Promise((resolve, reject) => {
                    db.query(outboundQuery, [`%${extensionNumber}%`], (error, results) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve({ date: formattedDate, type: 'outbound', count: results[0].outbound_call_count });
                        }
                    });
                }),
                new Promise((resolve, reject) => {
                    db.query(missedQuery, [`%${extensionNumber}%`], (error, results) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve({ date: formattedDate, type: 'missed', count: results[0].missed_call_count });
                        }
                    });
                })
            );
        }

        const results = await Promise.all(promises);
        return results;
    } catch (error) {
        console.error('Error fetching daily call counts:', error);
        throw error;
    }
}

// Endpoint to fetch daily call counts for past 7 days
router.get('/dailyCallCounts', async (req, res) => {
    const extensionNumber = req.query.extension;
    try {
        const dailyCallCounts = await fetchDailyCallCounts(extensionNumber);
        res.json(dailyCallCounts);
        // console.log("Bar Chart Data ",dailyCallCounts);
    } catch (error) {
        console.error('Error fetching daily call counts:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.get('/getUserByExtension', (req, res) => {
    const extensionNumber = req.query.extension;

    const query = `
        SELECT username, tenants_id FROM asterisk_cdr_rports.users
        WHERE extension = ?;
    `;

    db.query(query, [extensionNumber], (error, results) => {
        if (error) {
            console.error('Error executing query:', error);
            return res.status(500).json({ error: 'Internal Server Error' });
        }

        if (results.length > 0) {
            // Send the username back as a response
            res.json({ username: results[0].username, tenants_id: results[0].tenants_id });

        } else {
            // No user found with the given extension number
            res.status(404).json({ error: 'User not found' });
        }
    });
});

// get contact list
router.get('/getContactList', (req, res) => {
    const extensionNumber = req.query.extension;

    //console.log("getContactList " , extensionNumber);
    const query = `
        SELECT * FROM asterisk_cdr_rports.contacts where extension=?;
    `;

    db.query(query, [extensionNumber], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        //const getContactList = results[0].inbound_call_count; // Corrected alias name
        //console.log('Icontact list Count:', results); // Log count to console
        res.json(results); // Respond with JSON containing count
    });
});

// add new contact list
router.post('/addNewContact', (req, res) => {
    const extensionNumber = req.query.extension;
    const contactName = req.body.contactName;
    const contactPhone = req.body.contactPhone;

    // Insert login record into agent_login_logout table
    const insertQuery = `
          INSERT INTO asterisk_cdr_rports.contacts (mobile_no, name, extension, tenant_id)
          VALUES (?, ?, ?, ?)
        `;

    db.query(insertQuery, [contactPhone, contactName, extensionNumber, '1'], (error, results) => {
        if (error) {
            console.error('Error inserting login record:', error);
            return res.status(500).json({ error: 'Internal Server Error' });
        }

        //console.log("Login record inserted for extension:", extensionNumber);
        return res.json(results);
    });

});

// get contact list
router.get('/getOutboundNumberList', (req, res) => {
    const extensionNumber = req.query.extension;

    //console.log("getContactList " , extensionNumber);
    const query = `
        SELECT a.caller_num, service_name FROM asterisk_cdr_rports.tenants_agent a
        join asterisk_cdr_rports.tenants_number n on a.caller_num = n.caller_num
        where extension=?;
    `;

    db.query(query, [extensionNumber], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        //const getContactList = results[0].inbound_call_count; // Corrected alias name
        // console.log('Icontact list Count:', results); // Log count to console
        res.json(results); // Respond with JSON containing count
    });
});



// update outbound list
// router.post('/updateOutboundService', (req, res) => {
//     const extensionNumber = req.body.extension;
//     const tenants_id = req.body.tenants_id;
//     const selected_outbound_number = req.body.selected_outbound_number;
//     // const tenants_id = req.tenants_id;

//     //console.log("update out bound service ", extensionNumber, ' ', tenants_id, ' ', selected_outbound_number);
//     // console.log("addNewContact tenants_id " , tenants_id);
//     const query = `
//         Insert into asterisk_cdr_rports.agent_outbound_number (caller_id, tenant_id, extension) values (?,?,?);
//     `;

//     db.query(query, [selected_outbound_number, tenants_id, extensionNumber], (error, results, fields) => {
//         if (error) {
//             console.error('Error fetching data:', error);
//             res.status(500).json({ error: 'Internal Server Error' });
//             return;
//         }
//         return res.json(results);
//     });
// });

// get inbound call list
router.get('/getInboundCallList', (req, res) => {
    const extensionNumber = req.query.extension;

    //console.log("getContactList " , extensionNumber);
    const query = `
       SELECT 
   c.calldate ,unique_id, queue_name, event_type, SUBSTRING_INDEX(SUBSTRING_INDEX(event_parameters, '|', 2), '|', -1) AS talk_time
FROM 
    asterisk_cdr_rports.test_queue_log q
JOIN 
    (SELECT @row_number := 0) AS temp
JOIN asterisk_cdr_rports.cdr c ON q.unique_id = c.uniqueid
WHERE 
    (event_type = 'COMPLETEAGENT' OR event_type = 'COMPLETECALLER') 
    AND SUBSTRING_INDEX(SUBSTRING_INDEX(q.queue_member_channel, ' ', -1), '-', 1) = ?
group by c.uniqueid DESC;
    `;

    db.query(query, [extensionNumber], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        //const getContactList = results[0].inbound_call_count; // Corrected alias name
        //console.log('getInboundCallList list Count:', results); // Log count to console
        res.json(results); // Respond with JSON containing count
    });
});

// get inbound call list
router.get('/getOutboundCallList', (req, res) => {
    const extensionNumber = req.query.extension;

    //console.log("getContactList " , extensionNumber);
    const query = `
        select uniqueid, calldate, billsec, disposition from asterisk_cdr_rports.cdr 
where SUBSTRING_INDEX(SUBSTRING_INDEX(clid, '"', 2), '"', -1) = ? AND calldate>'2024-09-01' AND lastapp='Dial' group by uniqueid DESC ;
    `;

    db.query(query, [extensionNumber], (error, results, fields) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        //const getContactList = results[0].inbound_call_count; // Corrected alias name
        //console.log('getInboundCallList list Count:', results); // Log count to console
        res.json(results); // Respond with JSON containing count
    });
});


module.exports = router;
